import { siteContent } from "./siteContent.js";

// We import the projects from siteContent to avoid duplicating data.
// This way, the source of truth remains siteContent.js, but the animation 
// controller can still pull from this specific configuration file.

export const DEBUG_WORK_ANIMATIONS = false;

// Export exactly 6 projects for the animations so we do not have duplicates
export const radialCards = [...siteContent.projects];

export const diceCards = [...siteContent.projects];

export const birdCards = [...siteContent.projects];
