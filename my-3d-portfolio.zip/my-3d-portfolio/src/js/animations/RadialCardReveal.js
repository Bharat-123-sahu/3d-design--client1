/**
 * RadialCardReveal.js
 * Section 1 — Radial / Diagonal Card Convergence
 */

import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { DEBUG_WORK_ANIMATIONS } from "../data/workAnimationData.js";

gsap.registerPlugin(ScrollTrigger);

// Percentage-based origins (% of viewport)
const DIRECTIONS = [
  { key: "north", x: 0, y: -90 },
  { key: "northeast", x: 80, y: -70 },
  { key: "east", x: 110, y: 0 },
  { key: "southeast", x: 80, y: 70 },
  { key: "south", x: 0, y: 90 },
  { key: "southwest", x: -80, y: 70 },
  { key: "west", x: -110, y: 0 },
  { key: "northwest", x: -80, y: -70 },
];

export class RadialCardReveal {
  constructor(sectionEl, cards) {
    this.section = sectionEl;
    this.cards = cards;
    this.cardEls = [];
    this.tl = null;
    this.st = null;
    this._ready = false;
  }

  init() {
    this._buildDOM();
    this._buildTimeline();
    this._bindScrollTrigger();
    this._ready = true;
    if (DEBUG_WORK_ANIMATIONS) console.log("[RadialCardReveal] init complete");
  }

  kill() {
    this.st?.kill();
    this.tl?.kill();
    this.st = null;
    this.tl = null;
    this._ready = false;
    if (DEBUG_WORK_ANIMATIONS) console.log("[RadialCardReveal] killed");
  }

  destroy() {
    this.kill();
    this.cardEls.forEach((el) => el.remove());
    this.cardEls = [];
  }

  refresh() {
    this.kill();
    this._buildTimeline();
    this._bindScrollTrigger();
    this._ready = true;
  }

  _buildDOM() {
    const stage = this.section.querySelector(".radial-stage");
    if (!stage) return;

    stage.innerHTML = "";
    this.cardEls = [];

    this.cards.forEach((cardData, i) => {
      const dir = DIRECTIONS[i % DIRECTIONS.length];
      const card = document.createElement("div");
      card.className = "radial-card";
      card.dataset.direction = dir.key;
      card.dataset.index = i;

      card.innerHTML = `
        <div class="radial-card__inner work-anim-card">
          <div class="work-anim-card__image" style="background:${cardData.color}15;">
            ${
              cardData.image
                ? `<img src="${cardData.image}" alt="${cardData.title}" loading="lazy">`
                : `<div class="work-anim-card__placeholder" style="--card-color:${cardData.color};"></div>`
            }
            <span class="work-anim-card__badge">${cardData.categoryLabel || cardData.category}</span>
          </div>
          <div class="work-anim-card__body">
            <h3 class="work-anim-card__title">${cardData.title}</h3>
            <p class="work-anim-card__desc">${cardData.description}</p>
            <span class="work-anim-card__year">${cardData.year}</span>
          </div>
        </div>
        ${DEBUG_WORK_ANIMATIONS ? `<div class="radial-debug-label">${dir.key.toUpperCase()} #${i + 1}</div>` : ""}
      `;
      stage.appendChild(card);
      this.cardEls.push(card);
    });
  }

  _getOrigin(index) {
    const dir = DIRECTIONS[index % DIRECTIONS.length];
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const scale = Math.min(vw, 900) < 600 ? 0.65 : 1;

    return {
      x: (dir.x / 100) * vw * scale,
      y: (dir.y / 100) * vh * scale,
    };
  }

  _buildTimeline() {
    this.tl = gsap.timeline({ paused: true });

    this.cardEls.forEach((card, i) => {
      const origin = this._getOrigin(i);
      gsap.set(card, {
        x: origin.x,
        y: origin.y,
        opacity: 0,
        scale: 0.85,
        rotation: (i % 2 === 0 ? 1 : -1) * 4,
        filter: "blur(8px)",
        zIndex: i + 1,
      });
    });

    const SEGMENT = 1;

    this.cardEls.forEach((card, i) => {
      const offset = i * SEGMENT;

      this.tl.to(
        card,
        {
          x: 0,
          y: 0,
          opacity: 1,
          scale: 1,
          rotation: 0,
          filter: "blur(0px)",
          duration: SEGMENT,
          ease: "power2.out",
        },
        offset
      );

      if (i > 0) {
        for (let prev = 0; prev < i; prev++) {
          this.tl.to(
            this.cardEls[prev],
            {
              scale: 0.94,
              opacity: 0.35,
              duration: SEGMENT,
              ease: "power2.out",
            },
            offset
          );
        }
      }
    });

    // Minimal settle time
    this.tl.to({}, { duration: 0.1 });

    if (DEBUG_WORK_ANIMATIONS) {
      console.log("[RadialCardReveal] timeline built, duration:", this.tl.totalDuration());
    }
  }

  _bindScrollTrigger() {
    const old = ScrollTrigger.getById("work:radial-reveal");
    old?.kill();

    const CARD_SCROLL = Math.max(window.innerHeight * 0.85, 650);
    const totalScroll = this.cards.length * CARD_SCROLL;

    this.st = ScrollTrigger.create({
      id: "work:radial-reveal",
      trigger: this.section,
      pin: true,
      scrub: true, // strict scrub
      start: "top top",
      end: () => "+=" + totalScroll,
      animation: this.tl,
      onEnter: () => DEBUG_WORK_ANIMATIONS && console.log("[RadialCardReveal] SECTION 1 START"),
      onLeave: () => DEBUG_WORK_ANIMATIONS && console.log("[RadialCardReveal] SECTION 1 COMPLETE"),
      onUpdate: (self) => {
        if (!DEBUG_WORK_ANIMATIONS) return;
        const cardIndex = Math.min(Math.floor(self.progress * this.cards.length), this.cards.length - 1);
        const dbg = this.section.querySelector(".radial-debug-info");
        if (dbg) {
          dbg.textContent = `progress: ${(self.progress * 100).toFixed(1)}% | card: ${cardIndex + 1}/${this.cards.length}`;
        }
      },
    });
  }
}
