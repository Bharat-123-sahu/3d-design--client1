/**
 * WorkScrollController.js
 * Master scroll controller for the three cinematic Work sections.
 *
 * Responsibilities:
 *  - instantiates RadialCardReveal, DiceCardReveal, BirdCardReveal
 *  - initialises each in sequence after DOM is ready
 *  - handles cleanup on route change
 *  - handles resize / refresh
 */

import { ScrollTrigger } from "gsap/ScrollTrigger";
import { RadialCardReveal } from "./RadialCardReveal.js";
import { DiceCardReveal } from "./DiceCardReveal.js";
import { BirdCardReveal } from "./BirdCardReveal.js";
import {
  radialCards,
  diceCards,
  birdCards,
  DEBUG_WORK_ANIMATIONS,
} from "../data/workAnimationData.js";

const SECTION_IDS = {
  radial: "#section-radial-reveal",
  dice: "#section-dice-reveal",
  bird: "#section-bird-reveal",
};

let _instance = null; // singleton guard

export class WorkScrollController {
  constructor() {
    if (_instance) {
      _instance.destroy();
    }
    _instance = this;

    this.managers = {};
    this._resizeTimer = null;
    this._onResize = this._handleResize.bind(this);
  }

  // ─── Public API ────────────────────────────────────────────────────

  init() {
    const radialEl = document.querySelector(SECTION_IDS.radial);
    const diceEl = document.querySelector(SECTION_IDS.dice);
    const birdEl = document.querySelector(SECTION_IDS.bird);

    if (!radialEl && !diceEl && !birdEl) return; // not on Work page

    if (radialEl) {
      this.managers.radial = new RadialCardReveal(radialEl, radialCards);
      this.managers.radial.init();
    }

    if (diceEl) {
      this.managers.dice = new DiceCardReveal(diceEl, diceCards);
      this.managers.dice.init();
    }

    if (birdEl) {
      this.managers.bird = new BirdCardReveal(birdEl, birdCards);
      this.managers.bird.init();
    }

    window.addEventListener("resize", this._onResize);

    if (DEBUG_WORK_ANIMATIONS) {
      console.log(
        "[WorkScrollController] initialised. Active managers:",
        Object.keys(this.managers),
      );
    }
  }

  destroy() {
    Object.values(this.managers).forEach((m) => m.destroy?.());
    this.managers = {};
    window.removeEventListener("resize", this._onResize);
    clearTimeout(this._resizeTimer);
    _instance = null;

    if (DEBUG_WORK_ANIMATIONS) console.log("[WorkScrollController] destroyed");
  }

  refresh() {
    Object.values(this.managers).forEach((m) => m.refresh?.());
    ScrollTrigger.refresh();
    if (DEBUG_WORK_ANIMATIONS) console.log("[WorkScrollController] refreshed");
  }

  // ─── Private ───────────────────────────────────────────────────────

  _handleResize() {
    clearTimeout(this._resizeTimer);
    this._resizeTimer = setTimeout(() => {
      this.refresh();
    }, 250);
  }
}

// ── Module-level init/cleanup helpers (used by main.js) ─────────────

let _controller = null;

export function initWorkAnimations() {
  // Only init on the work page
  if (!document.querySelector("#section-radial-reveal")) return;

  // Clean up any existing instance first
  _controller?.destroy();
  _controller = new WorkScrollController();
  _controller.init();
}

export function destroyWorkAnimations() {
  _controller?.destroy();
  _controller = null;
}
