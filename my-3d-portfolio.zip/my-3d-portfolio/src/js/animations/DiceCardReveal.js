/**
 * DiceCardReveal.js
 * Section 2 — 3D Dice Face Card Reveal
 */

import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { DEBUG_WORK_ANIMATIONS } from "../data/workAnimationData.js";

gsap.registerPlugin(ScrollTrigger);

// Rotations (Y, X) to bring each face front-facing
const FACE_ROTATIONS = {
  front: { ry: 0, rx: 0 },
  right: { ry: -90, rx: 0 },
  top: { ry: 0, rx: 90 },
  left: { ry: 90, rx: 0 },
  bottom: { ry: 0, rx: -90 },
  back: { ry: 180, rx: 0 },
};

const FACE_ORDER = ["front", "right", "top", "left", "bottom", "back"];

export class DiceCardReveal {
  constructor(sectionEl, cards) {
    this.section = sectionEl;
    this.cards = cards.slice(0, 6); // max 6 dice faces
    this.diceEl = null;
    this.cardPanels = [];
    this.tl = null;
    this.st = null;
  }

  init() {
    this._buildDOM();
    this._buildTimeline();
    this._bindScrollTrigger();
    if (DEBUG_WORK_ANIMATIONS) console.log("[DiceCardReveal] init complete");
  }

  kill() {
    this.st?.kill();
    this.tl?.kill();
    this.st = null;
    this.tl = null;
  }

  destroy() {
    this.kill();
  }

  refresh() {
    this.kill();
    this._buildTimeline();
    this._bindScrollTrigger();
  }

  _buildDOM() {
    const diceWrap = this.section.querySelector(".dice-wrap");
    const cardPanel = this.section.querySelector(".dice-card-panel");
    if (!diceWrap || !cardPanel) return;

    diceWrap.innerHTML = "";
    const dice = document.createElement("div");
    dice.className = "dice-3d";
    this.diceEl = dice;

    FACE_ORDER.forEach((face, i) => {
      const faceEl = document.createElement("div");
      faceEl.className = `dice-face dice-face--${face}`;

      const cardData = this.cards[i];
      if (cardData) {
        faceEl.innerHTML = `
          <div class="dice-face__image" style="background:${cardData.color}22;">
            ${
              cardData.image
                ? `<img src="${cardData.image}" alt="${cardData.title}" loading="lazy">`
                : `<div class="dice-face__placeholder" style="--card-color:${cardData.color};"></div>`
            }
          </div>
          <div class="dice-face__label">
            <span class="dice-face__cat">${cardData.categoryLabel || cardData.category}</span>
            <span class="dice-face__title">${cardData.title}</span>
          </div>
          ${DEBUG_WORK_ANIMATIONS ? `<div class="dice-debug">${face.toUpperCase()}</div>` : ""}
        `;
      } else {
        faceEl.classList.add("dice-face--empty");
      }

      dice.appendChild(faceEl);
    });

    diceWrap.appendChild(dice);

    cardPanel.innerHTML = this.cards
      .map(
        (c, i) => `
        <div class="dice-card-info ${i === 0 ? "is-active" : ""}" data-face-index="${i}">
          <span class="dice-card-info__index">0${i + 1}</span>
          <span class="dice-card-info__cat">${c.categoryLabel || c.category}</span>
          <h3 class="dice-card-info__title">${c.title}</h3>
          <p class="dice-card-info__desc">${c.description}</p>
          <span class="dice-card-info__year">${c.year}</span>
        </div>
      `
      )
      .join("");

    this.cardPanels = Array.from(cardPanel.querySelectorAll(".dice-card-info"));

    // Initial state
    gsap.set(dice, { rotateY: 0, rotateX: 0 });
    this.cardPanels.forEach((panel, i) => {
      gsap.set(panel, { autoAlpha: i === 0 ? 1 : 0, y: i === 0 ? 0 : 30 });
    });
  }

  _buildTimeline() {
    if (!this.diceEl) return;

    this.tl = gsap.timeline({ paused: true });
    const SEGMENT = 1;

    this.cards.forEach((card, i) => {
      const start = i * SEGMENT;

      if (i === 0) {
        // Face 0 already visible. Hold it.
        this.tl.to({}, { duration: SEGMENT }, start);
        return;
      }

      const face = FACE_ORDER[i];
      const rot = FACE_ROTATIONS[face];

      // Rotate dice
      this.tl.to(
        this.diceEl,
        {
          rotateY: rot.ry,
          rotateX: rot.rx,
          duration: 0.65,
          ease: "power2.inOut",
        },
        start
      );

      // Fade out previous card info
      if (this.cardPanels[i - 1]) {
        this.tl.to(
          this.cardPanels[i - 1],
          {
            autoAlpha: 0,
            y: -24,
            duration: 0.25,
            ease: "power2.in",
          },
          start + 0.3
        );
      }

      // Reveal current card info
      if (this.cardPanels[i]) {
        this.tl.fromTo(
          this.cardPanels[i],
          { autoAlpha: 0, y: 30 },
          {
            autoAlpha: 1,
            y: 0,
            duration: 0.3,
            ease: "power3.out",
          },
          start + 0.55
        );
      }

      // Fill remaining segment time to ensure total segment = 1
      this.tl.to({}, { duration: 0.35 }, start + 0.65);
    });

    // Minimal settle
    this.tl.to({}, { duration: 0.1 });

    if (DEBUG_WORK_ANIMATIONS) {
      console.log("[DiceCardReveal] timeline built, duration:", this.tl.totalDuration());
    }
  }

  _bindScrollTrigger() {
    const old = ScrollTrigger.getById("work:dice-reveal");
    old?.kill();

    const CARD_SCROLL = Math.max(window.innerHeight * 0.85, 650);
    const totalScroll = this.cards.length * CARD_SCROLL;

    this.st = ScrollTrigger.create({
      id: "work:dice-reveal",
      trigger: this.section,
      pin: true,
      scrub: true, // strict scrub
      start: "top top",
      end: () => "+=" + totalScroll,
      animation: this.tl,
      onEnter: () => DEBUG_WORK_ANIMATIONS && console.log("[DiceCardReveal] SECTION 2 START"),
      onLeave: () => DEBUG_WORK_ANIMATIONS && console.log("[DiceCardReveal] SECTION 2 COMPLETE"),
      onUpdate: (self) => {
        if (!DEBUG_WORK_ANIMATIONS) return;
        const faceIndex = Math.min(Math.floor(self.progress * this.cards.length), this.cards.length - 1);
        const dbg = this.section.querySelector(".dice-debug-info");
        if (dbg) {
          dbg.textContent = `progress: ${(self.progress * 100).toFixed(1)}% | face: ${faceIndex + 1}/${this.cards.length}`;
        }
      },
    });
  }
}
