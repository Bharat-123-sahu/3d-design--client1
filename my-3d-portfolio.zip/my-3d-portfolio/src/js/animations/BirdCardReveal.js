/**
 * BirdCardReveal.js
 * Section 3 — Bird Flight + Tree Perch Card Reveal
 *
 * Procedural SVG/CSS bird travels a curved path, lands on a tree branch,
 * and triggers a card reveal. Each bird → card sequence is driven by
 * a scrubbed GSAP timeline pinned by ScrollTrigger.
 *
 * One renderer / canvas is NOT created here — the animation is pure CSS/SVG/DOM.
 */

import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { MotionPathPlugin } from "gsap/MotionPathPlugin";
import { DEBUG_WORK_ANIMATIONS } from "../data/workAnimationData.js";

gsap.registerPlugin(ScrollTrigger, MotionPathPlugin);

// ── Tree branch anchor points (% of section height from top, % of width) ──
const BRANCH_ANCHORS = [
  { x: 55, y: 38 }, // branch 0 — upper right
  { x: 62, y: 46 }, // branch 1 — mid right
  { x: 48, y: 54 }, // branch 2 — mid left
  { x: 58, y: 60 }, // branch 3 — lower right
];

// Bird SVG path (silhouette)
const BIRD_SVG = `
<svg class="bird-silhouette" viewBox="0 0 60 30" xmlns="http://www.w3.org/2000/svg">
  <path class="bird-body" d="M30 15 Q20 10 5 8 Q15 14 10 20 Q20 16 30 15Z M30 15 Q40 10 55 8 Q45 14 50 20 Q40 16 30 15Z" fill="currentColor"/>
  <path class="bird-wing-left"  d="M30 15 Q16 6 2 4 Q12 12 8 18 Q18 13 30 15Z" fill="currentColor" transform-origin="30px 15px"/>
  <path class="bird-wing-right" d="M30 15 Q44 6 58 4 Q48 12 52 18 Q42 13 30 15Z" fill="currentColor" transform-origin="30px 15px"/>
  <ellipse class="bird-head" cx="30" cy="13" rx="3" ry="2.5" fill="currentColor"/>
</svg>
`;

export class BirdCardReveal {
  /**
   * @param {HTMLElement} sectionEl   The pinned section wrapper
   * @param {Array}       cards       Array of card data objects from workAnimationData
   */
  constructor(sectionEl, cards) {
    this.section = sectionEl;
    this.cards = cards;
    this.birdEls = [];
    this.cardEls = [];
    this.tl = null;
    this.st = null;
    this._wingTls = [];
  }

  // ─── Public API ────────────────────────────────────────────────────

  init() {
    this._buildDOM();
    this._buildTimeline();
    this._bindScrollTrigger();
    if (DEBUG_WORK_ANIMATIONS) console.log("[BirdCardReveal] init complete");
  }

  kill() {
    this.st?.kill();
    this.tl?.kill();
    this._wingTls.forEach((t) => t.kill());
    this.st = null;
    this.tl = null;
    this._wingTls = [];
  }

  destroy() {
    this.kill();
    this.birdEls.forEach((el) => el.remove());
    this.cardEls.forEach((el) => el.remove());
    this.birdEls = [];
    this.cardEls = [];
  }

  refresh() {
    this.kill();
    this._buildTimeline();
    this._bindScrollTrigger();
  }

  // ─── Private ───────────────────────────────────────────────────────

  _buildDOM() {
    const sceneEl = this.section.querySelector(".bird-scene");
    const cardsEl = this.section.querySelector(".bird-cards");
    if (!sceneEl || !cardsEl) return;

    sceneEl.innerHTML = "";
    cardsEl.innerHTML = "";
    this.birdEls = [];
    this.cardEls = [];

    // Build tree
    sceneEl.innerHTML = this._treeHTML();

    // Build birds + cards
    this.cards.forEach((cardData, i) => {
      const anchor = BRANCH_ANCHORS[i % BRANCH_ANCHORS.length];

      // Bird element
      const birdEl = document.createElement("div");
      birdEl.className = "bird-entity";
      birdEl.dataset.index = i;
      birdEl.style.color = cardData.color;
      birdEl.innerHTML = BIRD_SVG;
      sceneEl.appendChild(birdEl);
      this.birdEls.push(birdEl);

      // Branch target marker (invisible but used for positioning)
      const marker = document.createElement("div");
      marker.className = "bird-branch-target";
      marker.style.cssText = `left:${anchor.x}%;top:${anchor.y}%;`;
      sceneEl.appendChild(marker);

      // Card reveal
      const cardEl = document.createElement("div");
      cardEl.className = "bird-reveal-card work-anim-card";
      cardEl.dataset.index = i;
      cardEl.innerHTML = `
        <div class="work-anim-card__image" style="background:${cardData.color}15;">
          ${
            cardData.image
              ? `<img src="${cardData.image}" alt="${cardData.title}" loading="lazy">`
              : `<div class="work-anim-card__placeholder" style="--card-color:${cardData.color};"></div>`
          }
          <span class="work-anim-card__badge">${cardData.category}</span>
        </div>
        <div class="work-anim-card__body">
          <h3 class="work-anim-card__title">${cardData.title}</h3>
          <p class="work-anim-card__desc">${cardData.description}</p>
          <span class="work-anim-card__year">${cardData.year}</span>
        </div>
      `;
      cardsEl.appendChild(cardEl);
      this.cardEls.push(cardEl);

      if (DEBUG_WORK_ANIMATIONS) {
        const dbg = document.createElement("div");
        dbg.className = "bird-debug-label";
        dbg.textContent = `Bird ${i + 1} → Branch ${i}`;
        dbg.style.cssText = `left:${anchor.x}%;top:${anchor.y + 5}%;`;
        sceneEl.appendChild(dbg);
      }
    });

    // Set initial hidden state
    this.birdEls.forEach((b) =>
      gsap.set(b, { autoAlpha: 0, x: -200, y: 0, scale: 0.7, rotation: -10 }),
    );
    this.cardEls.forEach((c) =>
      gsap.set(c, { autoAlpha: 0, y: 40, scale: 0.92 }),
    );
  }

  _treeHTML() {
    return `
      <svg class="bird-tree" viewBox="0 0 400 500" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <!-- Trunk -->
        <rect x="185" y="350" width="30" height="150" rx="6" fill="currentColor" opacity="0.35"/>
        <!-- Main branches -->
        <line x1="200" y1="360" x2="120" y2="260" stroke="currentColor" stroke-width="12" stroke-linecap="round" opacity="0.3"/>
        <line x1="200" y1="360" x2="290" y2="240" stroke="currentColor" stroke-width="12" stroke-linecap="round" opacity="0.3"/>
        <!-- Sub-branches -->
        <line x1="120" y1="260" x2="80"  y2="190" stroke="currentColor" stroke-width="7" stroke-linecap="round" opacity="0.25"/>
        <line x1="120" y1="260" x2="170" y2="200" stroke="currentColor" stroke-width="7" stroke-linecap="round" opacity="0.25"/>
        <line x1="290" y1="240" x2="330" y2="170" stroke="currentColor" stroke-width="7" stroke-linecap="round" opacity="0.25"/>
        <line x1="290" y1="240" x2="250" y2="185" stroke="currentColor" stroke-width="7" stroke-linecap="round" opacity="0.25"/>
        <!-- Leaf clusters (circles) -->
        <circle cx="82"  cy="180" r="44" fill="currentColor" opacity="0.07"/>
        <circle cx="165" cy="195" r="36" fill="currentColor" opacity="0.07"/>
        <circle cx="330" cy="160" r="48" fill="currentColor" opacity="0.07"/>
        <circle cx="248" cy="178" r="38" fill="currentColor" opacity="0.07"/>
        <circle cx="200" cy="150" r="30" fill="currentColor" opacity="0.05"/>
      </svg>
    `;
  }

  _buildTimeline() {
    if (!this.birdEls.length) return;

    this.tl = gsap.timeline({ paused: true });

    const PER_BIRD = 3; // timeline units per bird sequence
    const FLY_DUR = 1.5;
    const APPROACH_DUR = 0.6;
    const LAND_DUR = 0.3;
    const SETTLE_DUR = 0.2;
    const CARD_DUR = 0.5;

    this.cards.forEach((cardData, i) => {
      const offset = i * PER_BIRD;
      const anchor = BRANCH_ANCHORS[i % BRANCH_ANCHORS.length];
      const bird = this.birdEls[i];
      const card = this.cardEls[i];

      // ── Phase 1: Bird appears off-screen left ──
      this.tl.set(
        bird,
        { autoAlpha: 0, x: -180, y: 120, scale: 0.6, rotation: -8 },
        offset,
      );
      this.tl.to(bird, { autoAlpha: 1, duration: 0.1 }, offset);

      // ── Phase 2+3: Bird flies in with arc ──
      // Curved path: left → rise → approach tree
      this.tl.to(
        bird,
        {
          x: `${(anchor.x / 100) * 100}%`,
          y: `-30%`,
          scale: 0.9,
          rotation: 5,
          duration: FLY_DUR,
          ease: "power1.inOut",
        },
        offset + 0.1,
      );

      // ── Phase 4: Approach ──
      this.tl.to(
        bird,
        {
          x: `${(anchor.x / 100) * 100}%`,
          y: `${((anchor.y - 8) / 100) * 100}%`,
          scale: 0.75,
          rotation: -5,
          duration: APPROACH_DUR,
          ease: "power2.out",
        },
        offset + FLY_DUR,
      );

      // ── Phase 5+6: Descend to branch ──
      this.tl.to(
        bird,
        {
          y: `${(anchor.y / 100) * 100}%`,
          scale: 0.68,
          rotation: 0,
          duration: LAND_DUR,
          ease: "power3.out",
        },
        offset + FLY_DUR + APPROACH_DUR,
      );

      // ── Wing flap: fast during flight, slow during landing ──
      const wingL = bird.querySelector(".bird-wing-left");
      const wingR = bird.querySelector(".bird-wing-right");
      if (wingL && wingR) {
        // Fast flap
        const fastTl = gsap.timeline({ repeat: -1 });
        fastTl
          .to([wingL, wingR], {
            scaleY: -1,
            duration: 0.12,
            ease: "power1.inOut",
          })
          .to([wingL, wingR], {
            scaleY: 1,
            duration: 0.12,
            ease: "power1.inOut",
          });

        const endTime = offset + FLY_DUR + APPROACH_DUR;

        // Insert fast wing flap into master tl
        this.tl.add(() => fastTl.play(), offset);
        // Slow down on landing
        this.tl.add(
          () => gsap.to(fastTl, { timeScale: 0.3, duration: 0.3 }),
          endTime - 0.3,
        );
        // Stop after landing
        this.tl.add(() => {
          fastTl.pause();
          gsap.to([wingL, wingR], { scaleY: 1, duration: 0.2 });
        }, endTime + LAND_DUR);

        this._wingTls.push(fastTl);
      }

      // ── Phase 7+8: Wings settle ──
      this.tl.to(
        bird,
        {
          rotation: 0,
          duration: SETTLE_DUR,
          ease: "elastic.out(1, 0.5)",
        },
        offset + FLY_DUR + APPROACH_DUR + LAND_DUR,
      );

      // ── Phase 9: Card reveals ──
      this.tl.to(
        card,
        {
          autoAlpha: 1,
          y: 0,
          scale: 1,
          duration: CARD_DUR,
          ease: "power3.out",
        },
        offset + FLY_DUR + APPROACH_DUR + LAND_DUR + SETTLE_DUR,
      );

      // Short pause between birds
      this.tl.to({}, { duration: 0.3 }, offset + PER_BIRD - 0.3);
    });

    // Final settle
    this.tl.to({}, { duration: 0.5 });

    if (DEBUG_WORK_ANIMATIONS) {
      console.log(
        "[BirdCardReveal] timeline built, duration:",
        this.tl.totalDuration(),
      );
    }
  }

  _bindScrollTrigger() {
    const totalBirds = this.cards.length;
    const scrollDist = totalBirds * window.innerHeight * 1.1;

    this.st = ScrollTrigger.create({
      id: "work:bird-reveal",
      trigger: this.section,
      pin: true,
      scrub: 1.6,
      start: "top top",
      end: `+=${scrollDist}`,
      animation: this.tl,
      onEnter: () => {
        if (DEBUG_WORK_ANIMATIONS)
          console.log("[BirdCardReveal] SECTION 3 START");
      },
      onLeave: () => {
        if (DEBUG_WORK_ANIMATIONS)
          console.log("[BirdCardReveal] SECTION 3 COMPLETE");
      },
      onUpdate: (self) => {
        if (!DEBUG_WORK_ANIMATIONS) return;
        const birdIndex = Math.min(
          Math.floor(self.progress * totalBirds),
          totalBirds - 1,
        );
        const dbg = this.section.querySelector(".bird-debug-info");
        if (dbg) {
          dbg.textContent = `progress: ${(self.progress * 100).toFixed(1)}% | bird: ${birdIndex + 1}/${totalBirds}`;
        }
      },
    });
  }
}
